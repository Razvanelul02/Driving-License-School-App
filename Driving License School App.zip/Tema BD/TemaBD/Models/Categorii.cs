﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Categorii
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CategorieID { get; set; }
        public string Nume { get; set; }
        public string Descriere { get; set; }

        public Categorii()
        {
            
        }

    }
}
