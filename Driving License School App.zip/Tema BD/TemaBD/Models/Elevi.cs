﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Elevi
    {  
       [Key]
       [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ElevID { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public DateTime Data_Nasterii { get; set; }
        public string Oras { get; set; }
        public string Strada { get; set; }

        public int NrTelefon { get; set; }
        public int InstructorID { get; set; }
        [ForeignKey("InstructorID")]
        public Instructori Instructor { get; set; }
        public int CategorieID { get; set; }

        public Elevi()
        {
            
        }
    }
}
