﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Instructori
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int InstructorID { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public int NrTelefon { get; set; }
        public int VehiculID { get; set; }
        [ForeignKey("VehiculID")]
        public Vehicule Vehicul { get; set; }



        public Instructori()
        {
            
        }

        
    }
}
