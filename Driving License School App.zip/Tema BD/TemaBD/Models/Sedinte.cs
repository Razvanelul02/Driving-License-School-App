﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Sedinte
    {
       [Key]
       [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SedintaID { get; set; }
         public int ElevID { get; set; }
        [ForeignKey("ElevID")]
        public Elevi Elev { get; set; }

        public int InstructorID { get; set; }
        [ForeignKey("InstructorID")]
        public Instructori Instructor { get; set; }
        public DateTime Data { get; set; }
        public string Ora { get; set; }

        public Sedinte()
        {
            
        }

    }
    
    
}
