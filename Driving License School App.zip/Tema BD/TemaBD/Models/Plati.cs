﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Plati
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlataID { get; set; }
        public int ElevID { get; set; }
        [ForeignKey("ElevID")]
        public Elevi Elev { get; set; }
        public int Suma { get; set; }
        public DateTime Data { get; set; }
        public string DetaliiPlata { get; set; }

        public Plati()
        {
            
        }

    }
}
