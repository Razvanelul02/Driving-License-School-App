﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TemaBD.Models
{
    public class Vehicule
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int VehiculID { get; set; }
        public string Model { get; set; }
        public int AnFabricatie { get; set; }

        public Vehicule()
        {
            
        }
    }
}
