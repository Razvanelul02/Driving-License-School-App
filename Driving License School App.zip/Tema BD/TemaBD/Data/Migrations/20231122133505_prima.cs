﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TemaBD.Data.Migrations
{
    public partial class prima : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categorii",
                columns: table => new
                {
                    CategorieID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Descriere = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorii", x => x.CategorieID);
                });

            migrationBuilder.CreateTable(
                name: "Vehicule",
                columns: table => new
                {
                    VehiculID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Model = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnFabricatie = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicule", x => x.VehiculID);
                });

            migrationBuilder.CreateTable(
                name: "Instructori",
                columns: table => new
                {
                    InstructorID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NrTelefon = table.Column<int>(type: "int", nullable: false),
                    VehiculID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Instructori", x => x.InstructorID);
                    table.ForeignKey(
                        name: "FK_Instructori_Vehicule_VehiculID",
                        column: x => x.VehiculID,
                        principalTable: "Vehicule",
                        principalColumn: "VehiculID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Elevi",
                columns: table => new
                {
                    ElevID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data_Nasterii = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Oras = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Strada = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NrTelefon = table.Column<int>(type: "int", nullable: false),
                    InstructorID = table.Column<int>(type: "int", nullable: false),
                    CategorieID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Elevi", x => x.ElevID);
                    table.ForeignKey(
                        name: "FK_Elevi_Instructori_InstructorID",
                        column: x => x.InstructorID,
                        principalTable: "Instructori",
                        principalColumn: "InstructorID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Plati",
                columns: table => new
                {
                    PlataID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ElevID = table.Column<int>(type: "int", nullable: false),
                    Suma = table.Column<int>(type: "int", nullable: false),
                    Data = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DetaliiPlata = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Plati", x => x.PlataID);
                    table.ForeignKey(
                        name: "FK_Plati_Elevi_ElevID",
                        column: x => x.ElevID,
                        principalTable: "Elevi",
                        principalColumn: "ElevID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Sedinte",
                columns: table => new
                {
                    SedintaID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ElevID = table.Column<int>(type: "int", nullable: false),
                    InstructorID = table.Column<int>(type: "int", nullable: false),
                    Data = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Ora = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sedinte", x => x.SedintaID);
                    table.ForeignKey(
                        name: "FK_Sedinte_Elevi_ElevID",
                        column: x => x.ElevID,
                        principalTable: "Elevi",
                        principalColumn: "ElevID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Sedinte_Instructori_InstructorID",
                        column: x => x.InstructorID,
                        principalTable: "Instructori",
                        principalColumn: "InstructorID",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Elevi_InstructorID",
                table: "Elevi",
                column: "InstructorID");

            migrationBuilder.CreateIndex(
                name: "IX_Instructori_VehiculID",
                table: "Instructori",
                column: "VehiculID");

            migrationBuilder.CreateIndex(
                name: "IX_Plati_ElevID",
                table: "Plati",
                column: "ElevID");

            migrationBuilder.CreateIndex(
                name: "IX_Sedinte_ElevID",
                table: "Sedinte",
                column: "ElevID");

            migrationBuilder.CreateIndex(
                name: "IX_Sedinte_InstructorID",
                table: "Sedinte",
                column: "InstructorID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categorii");

            migrationBuilder.DropTable(
                name: "Plati");

            migrationBuilder.DropTable(
                name: "Sedinte");

            migrationBuilder.DropTable(
                name: "Elevi");

            migrationBuilder.DropTable(
                name: "Instructori");

            migrationBuilder.DropTable(
                name: "Vehicule");
        }
    }
}
