﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TemaBD.Models;

namespace TemaBD.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<TemaBD.Models.Elevi>? Elevi { get; set; }
        public DbSet<TemaBD.Models.Sedinte>? Sedinte { get; set; }
        public DbSet<TemaBD.Models.Plati>? Plati { get; set; }
        public DbSet<TemaBD.Models.Instructori>? Instructori { get; set; }
        public DbSet<TemaBD.Models.Categorii>? Categorii { get; set; }
        public DbSet<TemaBD.Models.Vehicule>? Vehicule { get; set; }
      
    }
}