﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{
    public class CategoriisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CategoriisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Categoriis
        public async Task<IActionResult> Index()
        {
              return _context.Categorii != null ? 
                          View(await _context.Categorii.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Categorii'  is null.");
        }

        // GET: Categoriis/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Categorii == null)
            {
                return NotFound();
            }

            var categorii = await _context.Categorii
                .FirstOrDefaultAsync(m => m.CategorieID == id);
            if (categorii == null)
            {
                return NotFound();
            }

            return View(categorii);
        }

        // GET: Categoriis/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Categoriis/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CategorieID,Nume,Descriere")] Categorii categorii)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Categorii (Nume, Descriere) VALUES ('{categorii.Nume}', '{categorii.Descriere}')";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(categorii);
        }

        // GET: Categoriis/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Categorii == null)
            {
                return NotFound();
            }

            var categorii = await _context.Categorii.FindAsync(id);
            if (categorii == null)
            {
                return NotFound();
            }
            return View(categorii);
        }

        // POST: Categoriis/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CategorieID,Nume,Descriere")] Categorii categorii)
        {
            if (id != categorii.CategorieID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var sql = $"UPDATE Categorii SET Nume = '{categorii.Nume}', Descriere = '{categorii.Descriere}' WHERE CategorieID = {categorii.CategorieID}";
                    _context.Database.ExecuteSqlRaw(sql);

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CategoriiExists(categorii.CategorieID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return View(categorii);
        }

        // GET: Categoriis/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Categorii == null)
            {
                return NotFound();
            }

            var categorii = await _context.Categorii
                .FirstOrDefaultAsync(m => m.CategorieID == id);
            if (categorii == null)
            {
                return NotFound();
            }

            return View(categorii);
        }

        // POST: Categoriis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Categorii == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Categorii' is null.");
            }

            var sql = $"DELETE FROM Categorii WHERE CategorieID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }

        private bool CategoriiExists(int id)
        {
          return (_context.Categorii?.Any(e => e.CategorieID == id)).GetValueOrDefault();
        }
    }
}
