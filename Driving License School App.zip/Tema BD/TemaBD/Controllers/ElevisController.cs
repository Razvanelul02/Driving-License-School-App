﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{


    public class ElevViewModel
    {
        public int ElevID { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public DateTime Data_Nasterii { get; set; }
        public string Oras { get; set; }
        public string Strada { get; set; }

        public int NrTelefon { get; set; }
        public int InstructorID { get; set; }
        public int CategorieID { get; set; }
    }
    public class ElevisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ElevisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Elevis
        public async Task<IActionResult> Index()
        {
              return _context.Elevi != null ? 
                          View(await _context.Elevi.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Elevi'  is null.");
        }

        // GET: Elevis/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Elevi == null)
            {
                return NotFound();
            }

            var elevi = await _context.Elevi
                .FirstOrDefaultAsync(m => m.ElevID == id);
            if (elevi == null)
            {
                return NotFound();
            }

            return View(elevi);
        }

        // GET: Elevis/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Elevis/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nume,Prenume,Data_Nasterii,Oras,Strada,NrTelefon,InstructorID,CategorieID")] ElevViewModel elevViewModel)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Elevi (Nume, Prenume, Data_Nasterii, Oras, Strada, NrTelefon, InstructorID, CategorieID) " +
                          $"VALUES ('{elevViewModel.Nume}', '{elevViewModel.Prenume}', " +
                          $"'{elevViewModel.Data_Nasterii.ToString("yyyy-MM-dd")}', " +
                          $"'{elevViewModel.Oras}', '{elevViewModel.Strada}', " +
                          $"{elevViewModel.NrTelefon}, {elevViewModel.InstructorID}, {elevViewModel.CategorieID})";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(elevViewModel);
        }

        // GET: Elevis/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Elevi == null)
            {
                return NotFound();
            }

            var elevi = await _context.Elevi.FindAsync(id);
            if (elevi == null)
            {
                return NotFound();
            }
            return View(elevi);
        }

        // POST: Elevis/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ElevID,Nume,Prenume,Data_Nasterii,Oras,Strada,NrTelefon,InstructorID,CategorieID")] ElevViewModel elevViewModel)
        {
            if (id != elevViewModel.ElevID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var sql = $"UPDATE Elevi SET Nume = '{elevViewModel.Nume}', " +
                              $"Prenume = '{elevViewModel.Prenume}', " +
                              $"Data_Nasterii = '{elevViewModel.Data_Nasterii.ToString("yyyy-MM-dd")}', " +
                              $"Oras = '{elevViewModel.Oras}', " +
                              $"Strada = '{elevViewModel.Strada}', " +
                              $"NrTelefon = {elevViewModel.NrTelefon}, " +
                              $"InstructorID = {elevViewModel.InstructorID}, " +
                              $"CategorieID = {elevViewModel.CategorieID} " +
                              $"WHERE ElevID = {elevViewModel.ElevID}";

                    _context.Database.ExecuteSqlRaw(sql);

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EleviExists(elevViewModel.ElevID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return View(elevViewModel);
        }

        // GET: Elevis/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Elevi == null)
            {
                return NotFound();
            }

            var elevi = await _context.Elevi
                .FirstOrDefaultAsync(m => m.ElevID == id);
            if (elevi == null)
            {
                return NotFound();
            }

            return View(elevi);
        }

        // POST: Elevis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Elevi == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Elevi' is null.");
            }

            var sql = $"DELETE FROM Elevi WHERE ElevID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }
        private bool EleviExists(int id)
        {
          return (_context.Elevi?.Any(e => e.ElevID == id)).GetValueOrDefault();
        }
    }
}
