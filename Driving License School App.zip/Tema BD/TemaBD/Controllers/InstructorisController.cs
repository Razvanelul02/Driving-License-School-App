﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{

    public class InstructorViewModel
    {
        public int InstructorID { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public int NrTelefon { get; set; }
        public int VehiculID { get; set; }
    }

    public class InstructorisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public InstructorisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Instructoris
        public async Task<IActionResult> Index()
        {
            return _context.Instructori != null ?
                        View(await _context.Instructori.ToListAsync()) :
                        Problem("Entity set 'ApplicationDbContext.Instructori'  is null.");
        }

        // GET: Instructoris/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Instructori == null)
            {
                return NotFound();
            }

            var instructori = await _context.Instructori
                .FirstOrDefaultAsync(m => m.InstructorID == id);
            if (instructori == null)
            {
                return NotFound();
            }

            return View(instructori);
        }

        // GET: Instructoris/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Instructoris/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Nume,Prenume,NrTelefon,VehiculID")] InstructorViewModel instructorViewModel)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Instructori (Nume, Prenume, NrTelefon, VehiculID) VALUES " +
                          $"('{instructorViewModel.Nume}', '{instructorViewModel.Prenume}', " +
                          $"{instructorViewModel.NrTelefon}, {instructorViewModel.VehiculID})";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(instructorViewModel);
        }
        // GET: Instructoris/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Instructori == null)
            {
                return NotFound();
            }

            var instructori = await _context.Instructori.FindAsync(id);
            if (instructori == null)
            {
                return NotFound();
            }
            return View(instructori);
        }

        // POST: Instructoris/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("InstructorID,Nume,Prenume,NrTelefon,VehiculID")] InstructorViewModel instructorViewModel)
        {
            if (id != instructorViewModel.InstructorID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var sql = $"UPDATE Instructori SET Nume = '{instructorViewModel.Nume}', " +
                              $"Prenume = '{instructorViewModel.Prenume}', " +
                              $"NrTelefon = {instructorViewModel.NrTelefon}, " +
                              $"VehiculID = {instructorViewModel.VehiculID} " +
                              $"WHERE InstructorID = {instructorViewModel.InstructorID}";

                    _context.Database.ExecuteSqlRaw(sql);

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!InstructoriExists(instructorViewModel.InstructorID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return View(instructorViewModel);
        }
        // GET: Instructoris/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Instructori == null)
            {
                return NotFound();
            }

            var instructori = await _context.Instructori
                .FirstOrDefaultAsync(m => m.InstructorID == id);
            if (instructori == null)
            {
                return NotFound();
            }

            return View(instructori);
        }

        // POST: Instructoris/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Instructori == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Instructori' is null.");
            }

            var sql = $"DELETE FROM Instructori WHERE InstructorID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }

        private bool InstructoriExists(int id)
        {
            return (_context.Instructori?.Any(e => e.InstructorID == id)).GetValueOrDefault();
        }
    }
}
