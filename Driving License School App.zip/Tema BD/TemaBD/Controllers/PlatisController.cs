﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{


    public class PlataViewModel
    {
        public int PlataID { get; set; }
        public int ElevID { get; set; }
        public int Suma { get; set; }
        public DateTime Data { get; set; }
        public string DetaliiPlata { get; set; }
    }
    public class PlatisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PlatisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Platis
        public async Task<IActionResult> Index()
        {
              return _context.Plati != null ? 
                          View(await _context.Plati.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Plati'  is null.");
        }

        // GET: Platis/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Plati == null)
            {
                return NotFound();
            }

            var plati = await _context.Plati
                .FirstOrDefaultAsync(m => m.PlataID == id);
            if (plati == null)
            {
                return NotFound();
            }

            return View(plati);
        }

        // GET: Platis/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Platis/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ElevID,Suma,Data,DetaliiPlata")] PlataViewModel plataViewModel)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Plati (ElevID, Suma, Data, DetaliiPlata) VALUES " +
                          $"({plataViewModel.ElevID}, {plataViewModel.Suma}, '{plataViewModel.Data}', '{plataViewModel.DetaliiPlata}')";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(plataViewModel);
        }

        // GET: Platis/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Plati == null)
            {
                return NotFound();
            }

            var plati = await _context.Plati.FindAsync(id);
            if (plati == null)
            {
                return NotFound();
            }
            return View(plati);
        }

        // POST: Platis/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PlataID,ElevID,Suma,Data,DetaliiPlata")] PlataViewModel plataViewModel)
        {
            if (id != plataViewModel.PlataID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var sql = $"UPDATE Plati SET ElevID = {plataViewModel.ElevID}, " +
                              $"Suma = {plataViewModel.Suma}, " +
                              $"Data = '{plataViewModel.Data}', " +
                              $"DetaliiPlata = '{plataViewModel.DetaliiPlata}' " +
                              $"WHERE PlataID = {plataViewModel.PlataID}";

                    _context.Database.ExecuteSqlRaw(sql);

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PlatiExists(plataViewModel.PlataID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return View(plataViewModel);
        }

        // GET: Platis/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Plati == null)
            {
                return NotFound();
            }

            var plati = await _context.Plati
                .FirstOrDefaultAsync(m => m.PlataID == id);
            if (plati == null)
            {
                return NotFound();
            }

            return View(plati);
        }

        // POST: Platis/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Plati == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Plati' is null.");
            }

            var sql = $"DELETE FROM Plati WHERE PlataID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }

        private bool PlatiExists(int id)
        {
          return (_context.Plati?.Any(e => e.PlataID == id)).GetValueOrDefault();
        }
    }
}
