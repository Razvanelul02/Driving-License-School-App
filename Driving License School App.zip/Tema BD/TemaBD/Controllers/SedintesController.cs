﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{


    public class SedintaViewModel
    {
        public int SedintaID { get; set; }
        public int ElevID { get; set; }
        public int InstructorID { get; set; }
        public DateTime Data { get; set; }
        public string Ora { get; set; }
    }
    public class SedintesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SedintesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Sedintes
        public async Task<IActionResult> Index()
        {
              return _context.Sedinte != null ? 
                          View(await _context.Sedinte.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Sedinte'  is null.");
        }

        // GET: Sedintes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Sedinte == null)
            {
                return NotFound();
            }

            var sedinte = await _context.Sedinte
                .FirstOrDefaultAsync(m => m.SedintaID == id);
            if (sedinte == null)
            {
                return NotFound();
            }

            return View(sedinte);
        }

        // GET: Sedintes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Sedintes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ElevID,InstructorID,Data,Ora")] SedintaViewModel sedintaViewModel)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Sedinte (ElevID, InstructorID, Data, Ora) VALUES " +
                          $"({sedintaViewModel.ElevID}, {sedintaViewModel.InstructorID}, '{sedintaViewModel.Data}', '{sedintaViewModel.Ora}')";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(sedintaViewModel);
        }

        // GET: Sedintes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Sedinte == null)
            {
                return NotFound();
            }

            var sedinte = await _context.Sedinte.FindAsync(id);
            if (sedinte == null)
            {
                return NotFound();
            }
            return View(sedinte);
        }

        // POST: Sedintes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SedintaID,ElevID,InstructorID,Data,Ora")] SedintaViewModel sedintaViewModel)
        {
            if (id != sedintaViewModel.SedintaID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var sql = $"UPDATE Sedinte SET ElevID = {sedintaViewModel.ElevID}, " +
                              $"InstructorID = {sedintaViewModel.InstructorID}, " +
                              $"Data = '{sedintaViewModel.Data}', " +
                              $"Ora = '{sedintaViewModel.Ora}' " +
                              $"WHERE SedintaID = {sedintaViewModel.SedintaID}";

                    _context.Database.ExecuteSqlRaw(sql);

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SedinteExists(sedintaViewModel.SedintaID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            return View(sedintaViewModel);
        }

        // GET: Sedintes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Sedinte == null)
            {
                return NotFound();
            }

            var sedinte = await _context.Sedinte
                .FirstOrDefaultAsync(m => m.SedintaID == id);
            if (sedinte == null)
            {
                return NotFound();
            }

            return View(sedinte);
        }

        // POST: Sedintes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Sedinte == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Sedinte' is null.");
            }

            var sql = $"DELETE FROM Sedinte WHERE SedintaID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }

        private bool SedinteExists(int id)
        {
          return (_context.Sedinte?.Any(e => e.SedintaID == id)).GetValueOrDefault();
        }
    }
}
