﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TemaBD.Data;
using TemaBD.Models;

namespace TemaBD.Controllers
{
    public class VehiculesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VehiculesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Vehicules
        public async Task<IActionResult> Index()
        {
              return _context.Vehicule != null ? 
                          View(await _context.Vehicule.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.Vehicule'  is null.");
        }

        // GET: Vehicules//SearchForm
        public async Task<IActionResult> ShowSearchForm()
        {
            return View();
                   
                       
        }

        // POST: Vehicules//SearchResults
        public async Task<IActionResult> ShowSearchResults(String SearchPhrase)
        {
            var sql = "SELECT v.* FROM Vehicule v " +
   "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
   $"WHERE i.Nume LIKE '%{SearchPhrase}%'";

            var sql1 = "SELECT v.* FROM Vehicule v " +
  "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
  "JOIN Elevi e ON i.InstructorID = e.InstructorID " +
  $"WHERE e.Oras LIKE '%{SearchPhrase}%'";

            var sql2 = "SELECT v.* FROM Vehicule v " +
  "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
  "JOIN Elevi e ON i.InstructorID = e.InstructorID " +
  "JOIN Plati p ON e.ElevID = p.ElevID " +
  $"WHERE p.Suma LIKE '%{SearchPhrase}%'";

            var sql3 = "SELECT v.* FROM Vehicule v " +
  "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
  "JOIN Elevi e ON i.InstructorID = e.InstructorID " +
  "JOIN Plati p ON e.ElevID = p.ElevID " +
  $"WHERE p.DetaliiPlata LIKE '%{SearchPhrase}%'";

            var sql4 = "SELECT v.* FROM Vehicule v " +
  "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
  "JOIN Elevi e ON i.InstructorID = e.InstructorID " +
  $"WHERE e.NrTelefon LIKE '%{SearchPhrase}%'";

            var sql5 = "SELECT v.* FROM Vehicule v " +
  "JOIN  Instructori i ON v.VehiculID = i.VehiculID " +
  "JOIN Sedinte s ON i.InstructorID = s.InstructorID " +
  $"WHERE s.Ora LIKE '%{SearchPhrase}%'";

            var sql6 = "SELECT v.* " +
           "FROM Vehicule v " +
           "JOIN (SELECT TOP 1 i.VehiculID " +
             " FROM Instructori i " +
             $" WHERE i.Nume LIKE '%{SearchPhrase}%' " +
             " ORDER BY i.Nume ASC) as subquery ON v.VehiculID = subquery.VehiculID";




            var searchResults = await _context.Vehicule.FromSqlRaw(sql).ToListAsync();
            var searchResults1 = await _context.Vehicule.FromSqlRaw(sql1).ToListAsync();
            var searchResults2 = await _context.Vehicule.FromSqlRaw(sql2).ToListAsync();
            var searchResults3 = await _context.Vehicule.FromSqlRaw(sql3).ToListAsync();
            var searchResults4 = await _context.Vehicule.FromSqlRaw(sql4).ToListAsync();
            var searchResults5 = await _context.Vehicule.FromSqlRaw(sql5).ToListAsync();
            var searchResults6 = await _context.Vehicule.FromSqlRaw(sql6).ToListAsync();

            if (searchResults.Count != 0)
            {
                return View("Index", searchResults);

            }
            else if (searchResults1.Count != 0)
            {
                return View("Index", searchResults1);

            }
            else if (searchResults2.Count != 0)
            {
                return View("Index", searchResults2);

            }
            else if (searchResults3.Count != 0)
            {
                return View("Index", searchResults3);

            }
            else if (searchResults4.Count != 0)
            {
                return View("Index", searchResults4);

            }
            else if (searchResults5.Count != 0)
            {
                return View("Index", searchResults5);

            }
            else if (searchResults6.Count != 0)
            {
                return View("Index", searchResults6);

            }
            return View("Index", ShowSearchResults);
        }
            

            // GET: Vehicules/Details/5
            public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Vehicule == null)
            {
                return NotFound();
            }

            var vehicule = await _context.Vehicule
                .FirstOrDefaultAsync(m => m.VehiculID == id);
            if (vehicule == null)
            {
                return NotFound();
            }

            return View(vehicule);
        }

        // GET: Vehicules/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Vehicules/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VehiculID,Model,AnFabricatie")] Vehicule vehicule)
        {
            if (ModelState.IsValid)
            {
                var sql = $"INSERT INTO Vehicule (Model, AnFabricatie) VALUES ('{vehicule.Model}', {vehicule.AnFabricatie})";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(vehicule);
        }

        // GET: Vehicules/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Vehicule == null)
            {
                return NotFound();
            }

            var vehicule = await _context.Vehicule.FindAsync(id);
            if (vehicule == null)
            {
                return NotFound();
            }
            return View(vehicule);
        }

        // POST: Vehicules/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VehiculID,Model,AnFabricatie")] Vehicule vehicule)
        {
            if (id != vehicule.VehiculID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var sql = $"UPDATE Vehicule SET Model = '{vehicule.Model}', AnFabricatie = {vehicule.AnFabricatie} WHERE VehiculID = {vehicule.VehiculID}";
                _context.Database.ExecuteSqlRaw(sql);

                return RedirectToAction(nameof(Index));
            }
            return View(vehicule);
        }

        // GET: Vehicules/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Vehicule == null)
            {
                return NotFound();
            }

            var vehicule = await _context.Vehicule
                .FirstOrDefaultAsync(m => m.VehiculID == id);
            if (vehicule == null)
            {
                return NotFound();
            }

            return View(vehicule);
        }

        // POST: Vehicules/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Vehicule == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Vehicule' is null.");
            }

            var sql = $"DELETE FROM Vehicule WHERE VehiculID = {id}";
            _context.Database.ExecuteSqlRaw(sql);

            return RedirectToAction(nameof(Index));
        }

        private bool VehiculeExists(int id)
        {
          return (_context.Vehicule?.Any(e => e.VehiculID == id)).GetValueOrDefault();
        }
    }
}
